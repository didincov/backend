
from fastapi import FastAPI, HTTPException
from datetime import datetime
from sqlalchemy import create_engine, Column, Integer, String
from sqlalchemy.orm import declarative_base, sessionmaker
from pydantic import BaseModel, Field, field_validator
from sqlalchemy import Float

engine = create_engine("sqlite:///salon.db")
SessionLocal = sessionmaker(bind=engine)
Base = declarative_base()

app = FastAPI()

class ServiceCreate(BaseModel):
    categoryId: int
    title: str = Field(min_length=1, max_length=100)
    desc: str = Field(min_length=1, max_length=100)
    duration: int = Field(ge=30, le=180)
    price: float = Field(gt=0)

    @field_validator("title", "desc")
    @classmethod
    def check_empty_strings(cls, value):
        if not value.strip():
            raise ValueError("Поле не должно быть пустым")
        return value


@app.get("/")
def root():
    return {"message": "Salon API"}

class Master(Base):
    __tablename__ = "masters"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    specialization = Column(String, nullable=False)
    

Base.metadata.create_all(bind=engine)

class ServiceDB(Base):
    __tablename__ = "services"

    id = Column(Integer, primary_key=True, index=True)
    category_id = Column(Integer, nullable=False)
    title = Column(String(100), nullable=False)
    description = Column(String(100), nullable=False)
    duration = Column(Integer, nullable=False)
    price = Column(Float, nullable=False)

db = SessionLocal()

if db.query(Master).count() == 0:
    db.add_all([
        Master(name="Анна", specialization="Парикмахер"),
        Master(name="Андрей", specialization="Мастер маникюра")
    ])
    db.commit()

db.close()

class Service:
    def __init__(self, service_id, name, price):
        self.service_id = service_id
        self.name = name
        self.price = price


class Appointment:
    def __init__(self, appointment_id, client_name, master_id, service_id, time):
        self.appointment_id = appointment_id
        self.client_name = client_name
        self.master_id = master_id
        self.service_id = service_id
        self.time = time



services = [
    Service(1, "Стрижка", 1500),
    Service(2, "Маникюр", 1200)
]

appointments = []

categories = [
    {"id": 1, "name": "Стрижки и укладки", "servicesCount": 5},
    {"id": 2, "name": "Маникюр и педикюр", "servicesCount": 5},
    {"id": 3, "name": "Брови и ресницы", "servicesCount": 4},
    {"id": 4, "name": "Спа-процедуры", "servicesCount": 4}
]

def get_master(master_id: int):
    db = SessionLocal()
    master = db.query(Master).filter(Master.id == master_id).first()
    db.close()
    return master


def get_service(service_id: int):
    for service in services:
        if service.service_id == service_id:
            return service
    return None


def create_appointment(client_name: str,
                       master_id: int,
                       service_id: int,
                       time: str):

    master = get_master(master_id)
    service = get_service(service_id)

    if not client_name or not master or not service or not time:
        return None

    try:
        appointment_time = datetime.strptime(time, "%H:%M").time()
    except ValueError:
        return None

    start_time = datetime.strptime("08:00", "%H:%M").time()
    end_time = datetime.strptime("20:00", "%H:%M").time()

    if not (start_time <= appointment_time < end_time):
        return None

    appointment = Appointment(
        len(appointments) + 1,
        client_name,
        master.id,
        service.service_id,
        time
    )

    appointments.append(appointment)
    return appointment

first_appointment = create_appointment("Иванова А.А.", 1, 1, "10:00")
second_appointment = create_appointment("Петрова А.А.", 1, 1, "11:00")

print("Список записей:")

for appointment in appointments:
    print(appointment.client_name, appointment.time)

print("\nПроверка пустого имени:")
no_correct_appointment = create_appointment("", 1, 1, "12:00")
print(no_correct_appointment)

print("\nПроверка некорректного времени:")
no_correct_time = create_appointment("Сидорова А.А.", 1, 1, "00:00")
print(no_correct_time)

print("\nКоличество записей:")
print(len(appointments))

@app.get("/categories")
def get_categories():
    return categories

@app.get("/categories/{category_id}")
def get_category(category_id: int):
    for category in categories:
        if category["id"] == category_id:
            return category

    raise HTTPException(status_code=404, detail="Category not found")

@app.get("/masters")
def get_masters(specialization: str | None = None):
    db = SessionLocal()

    query = db.query(Master)

    if specialization:
        query = query.filter(Master.specialization == specialization)

    masters = query.all()

    result = [
        {
            "id": master.id,
            "name": master.name,
            "specialization": master.specialization
        }
        for master in masters
    ]

    db.close()
    return result

@app.get("/masters/{master_id}")
def get_master_by_id(master_id: int):
    db = SessionLocal()

    master = db.query(Master).filter(Master.id == master_id).first()

    db.close()

    if master is None:
        raise HTTPException(status_code=404, detail="Master not found")

    return {
        "id": master.id,
        "name": master.name,
        "specialization": master.specialization
    }
# python -m uvicorn Appointment:app --reload --port 8001

@app.post("/services", status_code=201)
def create_service(service: ServiceCreate):
    if not any(category["id"] == service.categoryId for category in categories):
        raise HTTPException(status_code=404, detail="Category not found")

    db = SessionLocal()

    new_service = ServiceDB(
        category_id=service.categoryId,
        title=service.title,
        description=service.desc,
        duration=service.duration,
        price=service.price
    )

    db.add(new_service)
    db.commit()
    db.refresh(new_service)

    result = {
        "id": new_service.id,
        "categoryId": new_service.category_id,
        "title": new_service.title,
        "desc": new_service.description,
        "duration": new_service.duration,
        "price": new_service.price
    }

    db.close()
    return result